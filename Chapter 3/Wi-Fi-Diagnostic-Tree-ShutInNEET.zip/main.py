'''
Chapter 3 Exercise 17
Jake Schrecengost

This program that leads a person through the steps of fixing a bad Wi-Fi connection. This program ends as soon as a solution is found to the problem. 

Inputs: Did that fix the problem? (yes/no)
Constants: n/a
Outputs: Get a new router, Great! Have a nice day. 
'''

print('Reboot the computer and try to connect.')
answer = input('Did that fix the problem? (yes/no) ')

if answer == "yes":
  print('Great! Have a nice day.')
  exit()
elif answer == "no":
  print('Reboot the router and try to connect.')
else:
  print('Please only enter yes or no value.')
  exit()

answer = input('Did that fix the problem? (yes/no) ')

if answer == "yes":
  print('Great! Have a nice day.')
  exit()
elif answer == "no":
  print('Make sure the cables between the router and modem are plugged in firmly.')
else:
  print('Please only enter yes or no value.')
  exit()

answer = input('Did that fix the problem? (yes/no) ')

if answer == "yes":
  print('Great! Have a nice day.')
  exit()
elif answer == "no":
  print('Move the router to a new location.')
else:
  print('Please only enter yes or no value.')
  exit()

answer = input('Did that fix the problem? (yes/no) ')

if answer == "yes":
  print('Great! Have a nice day.')
  exit()
elif answer == "no":
  print('Get a new router.')
else:
  print('Please only enter yes or no value.')
  exit()