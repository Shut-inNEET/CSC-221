'''
Chapter 3 Exercise 13
Jake Schrecengost

A Fast Freight Shipping Company charges different rates depending on the weight of the package. This program will ask the user to enter the weight of a package and then display the following shipping charge.

Inputs: Weight of the package
Constants: rate0lbs_2lbs, rate3lbs_6lbs, rate7lbs_10lbs, rate10lbs_ex 
Outputs: Total shipping charge
'''

rate0lbs_2lbs = 1.50
rate3lbs_6lbs = 3.00
rate7lbs_10lbs = 4.00
rate10lbs_ex  = 4.75

packageweight = float(input('How many pounds does the package weigh? '))

if packageweight > 0 and packageweight <= 2:
  total = packageweight * rate0lbs_2lbs
elif packageweight >= 3 and packageweight <= 6:
  total = packageweight * rate3lbs_6lbs
elif packageweight >= 7 and packageweight <= 10:
  total = packageweight * rate7lbs_10lbs
elif packageweight >= 10:
  total = packageweight * rate10lbs_ex
else:
  print('Package weight is not within specified bounds. ')
  exit()

print(f'Your total shipping charge is ${total:.2f}')