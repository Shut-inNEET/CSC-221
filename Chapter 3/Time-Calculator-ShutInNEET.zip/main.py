'''
Chapter 3 Exercise 15
Jake Schrecengost

This program asks the user to enter a number of seconds and works as follows:
- There are 60 seconds in a minute. If the number of seconds entered by the user is greater than or equal to 60, the program will convert the number of seconds to minutes and seconds.
- There are 3,600 seconds in an hour. If the number of seconds entered by the user is greater than or equal to 3,600, the program will convert the number of seconds to hours, minutes, 
and seconds.
- There are 86,400 seconds in a day. If the number of seconds entered by the user is greater than or equal to 86,400, the program will convert the number of seconds to days, hours, minutes, and seconds.

Inputs: seconds
Constants: secondsinday, secondsinhour, secondsinminute
Outputs: The approximate converted length of time 
'''

secondsinday = 86400
secondsinhour = 3600
secondsinminute = 60

seconds = int(input('How many seconds? '))

if seconds >= secondsinday:
  days = seconds // secondsinday
  seconds = seconds % secondsinday
else:
  days = 0
if seconds >= secondsinhour:
  hours = seconds // secondsinhour
  seconds = seconds % secondsinhour
else:
  hours = 0
if seconds >= secondsinminute:
  minutes = seconds // secondsinminute
  seconds = seconds % secondsinminute
else:
  minutes = 0

print(f'The aproximate converted length of time is {days} days {hours} hours {minutes} minutes {seconds} seconds')
