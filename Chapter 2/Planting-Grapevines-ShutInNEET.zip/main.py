#Chapter 2 Exercise 13
#Jake Schrecengost

#This program tries to determine the number of vines that will fit in a row at a vineyard. The program prompts the user for the length of the row, the amount of space used by an end-post assembly, and the amount of space between the vines. This information is then put into a formula that will calculate the number of grapevines that will fit in one row.

#inputs: R (length of the row in feet), E (amount of space used by an end-post assembly in feet), S (space between vines in feet)
#calculate: V (number of grapevines that will fit in the row)
#outputs: V (number of grapevines that will fit in the row)

#ask for length of the row in feet
R = float(input('Length of the row in feet: '))
#ask for amount of space used by an end-post assembly in feet
E = float(input('Amount of space used by an end-post assembly in feet: '))
#ask for space between vines in feet
S = float(input('Space between vines in feet: '))

#calculate the meal tax
V = (R - 2 * E) // S

#display number of grapevines that will fit in the row 
print(f'Number of grapevines that will fit in the row: {V:.0f}')