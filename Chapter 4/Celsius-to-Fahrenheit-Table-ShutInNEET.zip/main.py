'''
Chapter 4 Exercise 6
Jake Schrecengost

This program displays a table of the Celsius temperatures 0 through 20 and their Fahrenheit equivalents.

Inputs: Celsius temperatures 0 through 20 (no user input needed technically)
Constants: n/a 
Outputs: Fahrenheit equivalents.
'''

print('Celsius\tFahrenheit')
print('-------------------')

for celsius in range(21):
  fahrenheit = (9/5) * celsius + 32
  print(f'{celsius}\t\t{fahrenheit:.1f}')