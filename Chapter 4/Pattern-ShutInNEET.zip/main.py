'''
Chapter 4 Exercise 14
Jake Schrecengost

This program uses nested loops to draw an upside down pyramid pattern.

Inputs: n/a
Constants: n/a 
Outputs: Pyramid pattern
'''
#Loop for rows is executed first 
for y in range(7):
  #Loop for columns is executed second 
  for x in range(7-y):
    #Columns are printed
    print('*', end ='')
  #Second loop is exited and new row is created
  print('')

