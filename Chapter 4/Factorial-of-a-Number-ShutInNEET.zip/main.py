'''
Chapter 4 Exercise 12
Jake Schrecengost

This program lets the user enter a nonnegative integer then uses a loop to calculate the factorial of that number. Then displays the factorial.

Inputs: Number 
Constants: Total
Outputs: Display the factorial of number
'''

Total = 1

Number = int(input("Input a nonnegative integer: "))
while Number < 0:
  Number = int(input("Please input a nonnegative integer: "))
for Factorial in range(1, Number+1):
  Total = Total * Factorial
print(f"Factorial of {Number} is {Total}")
