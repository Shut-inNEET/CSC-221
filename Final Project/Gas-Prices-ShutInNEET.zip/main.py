'''
Final Programming Project
Jake Schrecengost

This program will analyze gas prices between April 1993 and August 2013. It will be provided with a text file named GasPrices.txt. The file contains the weekly average prices for a gallon of gas in the United States, beginning on April 5th, 1993, and ending on August 26th, 2013. Each line in the file contains the average price for a gallon of gas on a specific date. Each line is
formatted in the following way: MM-DD-YYYY:Price 

This program is designed to:
1. Calculate the average price of gas per year. Then produce a report showing each year and the average gas price for that year.
2. For each year in the file, determine the date and amount for the lowest price, and the highest price. Then produce a report showing for each year, the lowest
price and date on which it occurred and the highest price and the date on which it occurred (showing one year per line).
3. Calculate the average price for each month in the file. Produce a report that shows each month and year and the average price for that month and year.
4. Generate a text file that lists the dates and prices, sorted from the lowest price to the highest
5. Generate a text file that lists the dates and prices, sorted from the highest price to the lowest.

Inputs: N/A
Constants: N/A
Outputs: Average Price Per Year, Highest and Lowest Prices Per Year, Average Price Per Month, List of Prices Lowest to Highest, List of Prices Highest to lowest
'''

def main():
  data, split_data, prices = gasprices_sheet()
  calc_avgperyear(data)
  highlow_peryear(data)
  calc_avgpermonth(data)
  lowtohigh_price(split_data, prices)
  hightolow_price(split_data, prices)

def gasprices_sheet():
  split_data = []
  prices = []
  infile = open('GasPrices.txt', 'r')
  data = infile.readlines()
  infile.close()
  for index in range(len(data)):
    data[index] = data[index].rstrip('\n')
    column = data[index].split(':')
    split_data.append(column)
    price = column[1]
    prices.append(price)
  return data, split_data, prices

def calc_avgperyear(data):

  print('List of Average Price Per Year...\n')
  
  total_1993 = 0
  for index in range(39):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_1993 += prices
    avg_1993 = total_1993 / 39
  print(f'The average price of gas in 1993 is: ${avg_1993:.2f}')

  total_1994 = 0
  for index in range(39, 91):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_1994 += prices
    avg_1994 = total_1994 / 52
  print(f'The average price of gas in 1994 is: ${avg_1994:.2f}')

  total_1995 = 0
  for index in range(91, 143):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_1995 += prices
    avg_1995 = total_1995 / 52
  print(f'The average price of gas in 1995 is: ${avg_1995:.2f}')

  total_1996 = 0
  for index in range(143, 196):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_1996 += prices
    avg_1996 = total_1996 / 53
  print(f'The average price of gas in 1996 is: ${avg_1996:.2f}')

  total_1997 = 0
  for index in range(196, 248):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_1997 += prices
    avg_1997 = total_1997 / 52
  print(f'The average price of gas in 1997 is: ${avg_1997:.2f}')

  total_1998 = 0
  for index in range(248, 300):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_1998 += prices
    avg_1998 = total_1998 / 52
  print(f'The average price of gas in 1998 is: ${avg_1998:.2f}')

  total_1999 = 0
  for index in range(300, 352):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_1999 += prices
    avg_1999 = total_1999 / 52
  print(f'The average price of gas in 1999 is: ${avg_1999:.2f}')

  total_2000 = 0
  for index in range(352, 404):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_2000 += prices
    avg_2000 = total_2000 / 52
  print(f'The average price of gas in 2000 is: ${avg_2000:.2f}')

  total_2001 = 0
  for index in range(404, 457):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_2001 += prices
    avg_2001 = total_2001 / 53
  print(f'The average price of gas in 2001 is: ${avg_2001:.2f}')

  total_2002 = 0
  for index in range(457, 509):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_2002 += prices
    avg_2002 = total_2002 / 52
  print(f'The average price of gas in 2002 is: ${avg_2002:.2f}')

  total_2003 = 0
  for index in range(509, 561):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_2003 += prices
    avg_2003 = total_2003 / 52
  print(f'The average price of gas in 2003 is: ${avg_2003:.2f}')

  total_2004 = 0
  for index in range(561, 613):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_2004 += prices
    avg_2004 = total_2004 / 52
  print(f'The average price of gas in 2004 is: ${avg_2004:.2f}')

  total_2005 = 0
  for index in range(613, 665):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_2005 += prices
    avg_2005 = total_2005 / 52
  print(f'The average price of gas in 2005 is: ${avg_2005:.2f}')

  total_2006 = 0
  for index in range(665, 717):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_2006 += prices
    avg_2006 = total_2006 / 52
  print(f'The average price of gas in 2006 is: ${avg_2006:.2f}')

  total_2007 = 0
  for index in range(717, 770):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_2007 += prices
    avg_2007 = total_2007 / 53
  print(f'The average price of gas in 2007 is: ${avg_2007:.2f}')

  total_2008 = 0
  for index in range(770, 822):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_2008 += prices
    avg_2008 = total_2008 / 52
  print(f'The average price of gas in 2008 is: ${avg_2008:.2f}')

  total_2009 = 0
  for index in range(822, 874):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_2009 += prices
    avg_2009 = total_2009 / 52
  print(f'The average price of gas in 2009 is: ${avg_2009:.2f}')

  total_2010 = 0
  for index in range(874, 926):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_2010 += prices
    avg_2010 = total_2010 / 52
  print(f'The average price of gas in 2010 is: ${avg_2010:.2f}')

  total_2011 = 0
  for index in range(926, 978):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_2011 += prices
    avg_2011 = total_2011 / 52
  print(f'The average price of gas in 2011 is: ${avg_2011:.2f}')

  total_2012 = 0
  for index in range(978, 1031):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_2012 += prices
    avg_2012 = total_2012 / 53
  print(f'The average price of gas in 2012 is: ${avg_2012:.2f}')

  total_2013 = 0
  for index in range(1031, 1065):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_2013 += prices
    avg_2013 = total_2013 / 34
  print(f'The average price of gas in 2013 is: ${avg_2013:.2f}\n')

def highlow_peryear(data):

  print('List of Highest and Lowest Prices Per Year...\n')

  prices_1993 = []
  for index in range(39):
    if len(data[index]) == 16:
      prices = data[index][-5 :]
    else:
      prices = data[index][-4 :]
    prices_1993.append(prices)
  print(f'The lowest price of gas in 1993 is: ${min(prices_1993)}', end = "")
  print(f' and the highest price is: ${max(prices_1993)}')

  prices_1994 = []
  for index in range(39, 91):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_1994.append(prices)
  print(f'The lowest price of gas in 1994 is: ${min(prices_1994)}', end = "")
  print(f' and the highest price is: ${max(prices_1994)}')

  prices_1995 = []
  for index in range(91, 143):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_1995.append(prices)
  print(f'The lowest price of gas in 1995 is: ${min(prices_1995)}', end = "")
  print(f' and the highest price is: ${max(prices_1995)}')

  prices_1996 = []
  for index in range(143, 196):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_1996.append(prices)
  print(f'The lowest price of gas in 1996 is: ${min(prices_1996)}', end = "")
  print(f' and the highest price is: ${max(prices_1996)}')

  prices_1997 = []
  for index in range(196, 248):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_1997.append(prices)
  print(f'The lowest price of gas in 1997 is: ${min(prices_1997)}', end = "")
  print(f' and the highest price is: ${max(prices_1997)}')

  prices_1998 = []
  for index in range(248, 300):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_1998.append(prices)
  print(f'The lowest price of gas in 1998 is: ${min(prices_1998)}', end = "")
  print(f' and the highest price is: ${max(prices_1998)}')

  prices_1999 = []
  for index in range(300, 352):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_1999.append(prices)
  print(f'The lowest price of gas in 1999 is: ${min(prices_1999)}', end = "")
  print(f' and the highest price is: ${max(prices_1999)}')

  prices_2000 = []
  for index in range(352, 404):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_2000.append(prices)
  print(f'The lowest price of gas in 2000 is: ${min(prices_2000)}', end = "")
  print(f' and the highest price is: ${max(prices_2000)}')

  prices_2001 = []
  for index in range(404, 457):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_2001.append(prices)
  print(f'The lowest price of gas in 2001 is: ${min(prices_2001)}', end = "")
  print(f' and the highest price is: ${max(prices_2001)}')

  prices_2002 = []
  for index in range(457, 509):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_2002.append(prices)
  print(f'The lowest price of gas in 2002 is: ${min(prices_2002)}', end = "")
  print(f' and the highest price is: ${max(prices_2002)}')

  prices_2003 = []
  for index in range(509, 561):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_2003.append(prices)
  print(f'The lowest price of gas in 2003 is: ${min(prices_2003)}', end = "")
  print(f' and the highest price is: ${max(prices_2003)}')

  prices_2004 = []
  for index in range(561, 613):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_2004.append(prices)
  print(f'The lowest price of gas in 2004 is: ${min(prices_2004)}', end = "")
  print(f' and the highest price is: ${max(prices_2004)}')

  prices_2005 = []
  for index in range(613, 665):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_2005.append(prices)
  print(f'The lowest price of gas in 2005 is: ${min(prices_2005)}', end = "")
  print(f' and the highest price is: ${max(prices_2005)}')

  prices_2006 = []
  for index in range(665, 717):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_2006.append(prices)
  print(f'The lowest price of gas in 2006 is: ${min(prices_2006)}', end = "")
  print(f' and the highest price is: ${max(prices_2006)}')

  prices_2007 = []
  for index in range(717, 770):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_2007.append(prices)
  print(f'The lowest price of gas in 2007 is: ${min(prices_2007)}', end = "")
  print(f' and the highest price is: ${max(prices_2007)}')

  prices_2008 = []
  for index in range(770, 822):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_2008.append(prices)
  print(f'The lowest price of gas in 2008 is: ${min(prices_2008)}', end = "")
  print(f' and the highest price is: ${max(prices_2008)}')

  prices_2009 = []
  for index in range(822, 874):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_2009.append(prices)
  print(f'The lowest price of gas in 2009 is: ${min(prices_2009)}', end = "")
  print(f' and the highest price is: ${max(prices_2009)}')

  prices_2010 = []
  for index in range(874, 926):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_2010.append(prices)
  print(f'The lowest price of gas in 2010 is: ${min(prices_2010)}', end = "")
  print(f' and the highest price is: ${max(prices_2010)}')

  prices_2011 = []
  for index in range(926, 978):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_2011.append(prices)
  print(f'The lowest price of gas in 2011 is: ${min(prices_2011)}', end = "")
  print(f' and the highest price is: ${max(prices_2011)}')

  prices_2012 = []
  for index in range(978, 1031):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    prices_2012.append(prices)
  print(f'The lowest price of gas in 2012 is: ${min(prices_2012)}', end = "")
  print(f' and the highest price is: ${max(prices_2012)}')

  prices_2013 = []
  for index in range(1031, 1065):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    prices_2013.append(prices)
  print(f'The lowest price of gas in 2013 is: ${min(prices_2013)}', end = "")
  print(f' and the highest price is: ${max(prices_2013)}\n')

def calc_avgpermonth(data):

  print('List of Average Price Per Month...\n')
  
  total_apr1993 = 0
  for index in range(4):
    prices = float((data[index][-5 :]))
    total_apr1993 += prices
  avg_apr1993 = total_apr1993 / 4
  print(f'The average price of gas in 1993 in April is: ${avg_apr1993:.2f}')

  total_may1993 = 0
  for index in range(4, 9):
    prices = float((data[index][-5 :]))
    total_may1993 += prices
  avg_may1993 = total_may1993 / 5
  print(f'The average price of gas in 1993 in May is: ${avg_may1993:.2f}')

  total_jun1993 = 0
  for index in range(9, 13):
    prices = float((data[index][-5 :]))
    total_jun1993 += prices
  avg_jun1993 = total_jun1993 / 4
  print(f'The average price of gas in 1993 in June is: ${avg_jun1993:.2f}')

  total_jul1993 = 0
  for index in range(13, 17):
    prices = float((data[index][-5 :]))
    total_jul1993 += prices
  avg_jul1993 = total_jul1993 / 4
  print(f'The average price of gas in 1993 in July is: ${avg_jul1993:.2f}')

  total_aug1993 = 0
  for index in range(17, 22):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug1993 += prices
  avg_aug1993 = total_aug1993 / 5
  print(f'The average price of gas in 1993 in August is: ${avg_aug1993:.2f}')

  total_sep1993 = 0
  for index in range(22, 26):
    prices = float((data[index][-5 :]))
    total_sep1993 += prices
  avg_sep1993 = total_sep1993 / 4
  print(f'The average price of gas in 1993 in September is: ${avg_sep1993:.2f}')

  total_oct1993 = 0
  for index in range(26, 30):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct1993 += prices
  avg_oct1993 = total_oct1993 / 4
  print(f'The average price of gas in 1993 in October is: ${avg_oct1993:.2f}')

  total_nov1993 = 0
  for index in range(30, 35):
    prices = float((data[index][-5 :]))
    total_nov1993 += prices
  avg_nov1993 = total_nov1993 / 5
  print(f'The average price of gas in 1993 in November is: ${avg_nov1993:.2f}')

  total_dec1993 = 0
  for index in range(35, 39):
    prices = float((data[index][-5 :]))
    total_dec1993 += prices
  avg_dec1993 = total_dec1993 / 4
  print(f'The average price of gas in 1993 in December is: ${avg_dec1993:.2f}')

#1994...............................................

  total_jan1994 = 0
  for index in range(39, 44):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jan1994 += prices
  avg_jan1994 = total_jan1994 / 5
  print(f'The average price of gas in 1994 in January is: ${avg_jan1994:.2f}')

  total_feb1994 = 0
  for index in range(44, 48):
    prices = float((data[index][-5 :]))
    total_feb1994 += prices
  avg_feb1994 = total_feb1994 / 4
  print(f'The average price of gas in 1994 in February is: ${avg_feb1994:.2f}')

  total_mar1994 = 0
  for index in range(48, 52):
    prices = float((data[index][-5 :]))
    total_mar1994 += prices
  avg_mar1994 = total_mar1994 / 4
  print(f'The average price of gas in 1994 in March is: ${avg_mar1994:.2f}')

  total_apr1994 = 0
  for index in range(52, 56):
    prices = float((data[index][-5 :]))
    total_apr1994 += prices
  avg_apr1994 = total_apr1994 / 4
  print(f'The average price of gas in 1994 in April is: ${avg_apr1994:.2f}')

  total_may1994 = 0
  for index in range(56, 61):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may1994 += prices
  avg_may1994 = total_may1994 / 5
  print(f'The average price of gas in 1994 in May is: ${avg_may1994:.2f}')

  total_jun1994 = 0
  for index in range(61, 65):
    prices = float((data[index][-5 :]))
    total_jun1994 += prices
  avg_jun1994 = total_jun1994 / 4
  print(f'The average price of gas in 1994 in June is: ${avg_jun1994:.2f}')

  total_jul1994 = 0
  for index in range(65, 69):
    prices = float((data[index][-5 :]))
    total_jul1994 += prices
  avg_jul1994 = total_jul1994 / 4
  print(f'The average price of gas in 1994 in July is: ${avg_jul1994:.2f}')

  total_aug1994 = 0
  for index in range(69, 74):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug1994 += prices
  avg_aug1994 = total_aug1994 / 5
  print(f'The average price of gas in 1994 in August is: ${avg_aug1994:.2f}')

  total_sep1994 = 0
  for index in range(74, 78):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep1994 += prices
  avg_sep1994 = total_sep1994 / 4
  print(f'The average price of gas in 1994 in September is: ${avg_sep1994:.2f}')

  total_oct1994 = 0
  for index in range(78, 83):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct1994 += prices
  avg_oct1994 = total_oct1994 / 5
  print(f'The average price of gas in 1994 in October is: ${avg_oct1994:.2f}')

  total_nov1994 = 0
  for index in range(83, 87):
    prices = float((data[index][-5 :]))
    total_nov1994 += prices
  avg_nov1994 = total_nov1994 / 5
  print(f'The average price of gas in 1994 in November is: ${avg_nov1994:.2f}')

  total_dec1994 = 0
  for index in range(87, 91):
    prices = float((data[index][-5 :]))
    total_dec1994 += prices
  avg_dec1994 = total_dec1994 / 4
  print(f'The average price of gas in 1994 in December is: ${avg_dec1994:.2f}')

#1995...............................................

  total_jan1995 = 0
  for index in range(91, 96):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jan1995 += prices
  avg_jan1995 = total_jan1995 / 5
  print(f'The average price of gas in 1995 in January is: ${avg_jan1995:.2f}')

  total_feb1995 = 0
  for index in range(96, 100):
    prices = float((data[index][-5 :]))
    total_feb1995 += prices
  avg_feb1995 = total_feb1995 / 4
  print(f'The average price of gas in 1995 in February is: ${avg_feb1995:.2f}')

  total_mar1995 = 0
  for index in range(100, 104):
    prices = float((data[index][-5 :]))
    total_mar1995 += prices
  avg_mar1995 = total_mar1995 / 4
  print(f'The average price of gas in 1995 in March is: ${avg_mar1995:.2f}')

  total_apr1995 = 0
  for index in range(104, 108):
    prices = float((data[index][-5 :]))
    total_apr1995 += prices
  avg_apr1995 = total_apr1995 / 4
  print(f'The average price of gas in 1995 in April is: ${avg_apr1995:.2f}')

  total_may1995 = 0
  for index in range(108, 113):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may1995 += prices
  avg_may1995 = total_may1995 / 5
  print(f'The average price of gas in 1995 in May is: ${avg_may1995:.2f}')

  total_jun1995 = 0
  for index in range(113, 117):
    prices = float((data[index][-5 :]))
    total_jun1995 += prices
  avg_jun1995 = total_jun1995 / 4
  print(f'The average price of gas in 1995 in June is: ${avg_jun1995:.2f}')

  total_jul1995 = 0
  for index in range(117, 122):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul1995 += prices
  avg_jul1995 = total_jul1995 / 5
  print(f'The average price of gas in 1995 in July is: ${avg_jul1995:.2f}')

  total_aug1995 = 0
  for index in range(122, 126):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug1995 += prices
  avg_aug1995 = total_aug1995 / 4
  print(f'The average price of gas in 1995 in August is: ${avg_aug1995:.2f}')

  total_sep1995 = 0
  for index in range(126, 130):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep1995 += prices
  avg_sep1995 = total_sep1995 / 4
  print(f'The average price of gas in 1995 in September is: ${avg_sep1995:.2f}')

  total_oct1995 = 0
  for index in range(130, 135):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct1995 += prices
  avg_oct1995 = total_oct1995 / 5
  print(f'The average price of gas in 1995 in October is: ${avg_oct1995:.2f}')

  total_nov1995 = 0
  for index in range(135, 139):
    prices = float((data[index][-5 :]))
    total_nov1995 += prices
  avg_nov1995 = total_nov1995 / 4
  print(f'The average price of gas in 1995 in November is: ${avg_nov1995:.2f}')

  total_dec1995 = 0
  for index in range(139, 143):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec1995 += prices
  avg_dec1995 = total_dec1995 / 4
  print(f'The average price of gas in 1995 in December is: ${avg_dec1995:.2f}')

#1996...............................................

  total_jan1996 = 0
  for index in range(143, 148):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jan1996 += prices
  avg_jan1996 = total_jan1996 / 5
  print(f'The average price of gas in 1996 in January is: ${avg_jan1996:.2f}')

  total_feb1996 = 0
  for index in range(148, 152):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb1996 += prices
  avg_feb1996 = total_feb1996 / 4
  print(f'The average price of gas in 1996 in February is: ${avg_feb1996:.2f}')

  total_mar1996 = 0
  for index in range(152, 156):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar1996 += prices
  avg_mar1996 = total_mar1996 / 4
  print(f'The average price of gas in 1996 in March is: ${avg_mar1996:.2f}')

  total_apr1996 = 0
  for index in range(156, 161):
    prices = float((data[index][-5 :]))
    total_apr1996 += prices
  avg_apr1996 = total_apr1996 / 5
  print(f'The average price of gas in 1996 in April is: ${avg_apr1996:.2f}')

  total_may1996 = 0
  for index in range(161, 165):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may1996 += prices
  avg_may1996 = total_may1996 / 4
  print(f'The average price of gas in 1996 in May is: ${avg_may1996:.2f}')

  total_jun1996 = 0
  for index in range(165, 169):
    prices = float((data[index][-5 :]))
    total_jun1996 += prices
  avg_jun1996 = total_jun1996 / 4
  print(f'The average price of gas in 1996 in June is: ${avg_jun1996:.2f}')

  total_jul1996 = 0
  for index in range(169, 174):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul1996 += prices
  avg_jul1996 = total_jul1996 / 5
  print(f'The average price of gas in 1996 in July is: ${avg_jul1996:.2f}')

  total_aug1996 = 0
  for index in range(174, 178):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug1996 += prices
  avg_aug1996 = total_aug1996 / 4
  print(f'The average price of gas in 1996 in August is: ${avg_aug1996:.2f}')

  total_sep1996 = 0
  for index in range(178, 183):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep1996 += prices
  avg_sep1996 = total_sep1996 / 5
  print(f'The average price of gas in 1996 in September is: ${avg_sep1996:.2f}')

  total_oct1996 = 0
  for index in range(183, 187):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct1996 += prices
  avg_oct1996 = total_oct1996 / 4
  print(f'The average price of gas in 1996 in October is: ${avg_oct1996:.2f}')

  total_nov1996 = 0
  for index in range(187, 191):
    prices = float((data[index][-5 :]))
    total_nov1996 += prices
  avg_nov1996 = total_nov1996 / 4
  print(f'The average price of gas in 1996 in November is: ${avg_nov1996:.2f}')

  total_dec1996 = 0
  for index in range(191, 196):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec1996 += prices
  avg_dec1996 = total_dec1996 / 5
  print(f'The average price of gas in 1996 in December is: ${avg_dec1996:.2f}')

#1997...............................................
  
  total_jan1997 = 0
  for index in range(196, 200):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jan1997 += prices
  avg_jan1997 = total_jan1997 / 4
  print(f'The average price of gas in 1997 in January is: ${avg_jan1997:.2f}')

  total_feb1997 = 0
  for index in range(200, 204):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb1997 += prices
  avg_feb1997 = total_feb1997 / 4
  print(f'The average price of gas in 1997 in February is: ${avg_feb1997:.2f}')

  total_mar1997 = 0
  for index in range(204, 209):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar1997 += prices
  avg_mar1997 = total_mar1997 / 5
  print(f'The average price of gas in 1997 in March is: ${avg_mar1997:.2f}')

  total_apr1997 = 0
  for index in range(209, 213):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_apr1997 += prices
  avg_apr1997 = total_apr1997 / 4
  print(f'The average price of gas in 1997 in April is: ${avg_apr1997:.2f}')

  total_may1997 = 0
  for index in range(213, 217):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may1997 += prices
  avg_may1997 = total_may1997 / 4
  print(f'The average price of gas in 1997 in May is: ${avg_may1997:.2f}')

  total_jun1997 = 0
  for index in range(217, 222):
    prices = float((data[index][-5 :]))
    total_jun1997 += prices
  avg_jun1997 = total_jun1997 / 5
  print(f'The average price of gas in 1997 in June is: ${avg_jun1997:.2f}')

  total_jul1997 = 0
  for index in range(222, 226):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul1997 += prices
  avg_jul1997 = total_jul1997 / 4
  print(f'The average price of gas in 1997 in July is: ${avg_jul1997:.2f}')

  total_aug1997 = 0
  for index in range(226, 230):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug1997 += prices
  avg_aug1997 = total_aug1997 / 4
  print(f'The average price of gas in 1997 in August is: ${avg_aug1997:.2f}')

  total_sep1997 = 0
  for index in range(230, 235):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep1997 += prices
  avg_sep1997 = total_sep1997 / 5
  print(f'The average price of gas in 1997 in September is: ${avg_sep1997:.2f}')

  total_oct1997 = 0
  for index in range(235, 239):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct1997 += prices
  avg_oct1997 = total_oct1997 / 4
  print(f'The average price of gas in 1997 in October is: ${avg_oct1997:.2f}')

  total_nov1997 = 0
  for index in range(239, 243):
    prices = float((data[index][-5 :]))
    total_nov1997 += prices
  avg_nov1997 = total_nov1997 / 4
  print(f'The average price of gas in 1997 in November is: ${avg_nov1997:.2f}')

  total_dec1997 = 0
  for index in range(243, 248):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec1997 += prices
  avg_dec1997 = total_dec1997 / 5
  print(f'The average price of gas in 1997 in December is: ${avg_dec1997:.2f}')

#1998...............................................
  
  total_jan1998 = 0
  for index in range(248, 252):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jan1998 += prices
  avg_jan1998 = total_jan1998 / 4
  print(f'The average price of gas in 1998 in January is: ${avg_jan1998:.2f}')

  total_feb1998 = 0
  for index in range(252, 256):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb1998 += prices
  avg_feb1998 = total_feb1998 / 4
  print(f'The average price of gas in 1998 in February is: ${avg_feb1998:.2f}')

  total_mar1998 = 0
  for index in range(256, 261):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar1998 += prices
  avg_mar1998 = total_mar1998 / 5
  print(f'The average price of gas in 1998 in March is: ${avg_mar1998:.2f}')

  total_apr1998 = 0
  for index in range(261, 265):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_apr1998 += prices
  avg_apr1998 = total_apr1998 / 4
  print(f'The average price of gas in 1998 in April is: ${avg_apr1998:.2f}')

  total_may1998 = 0
  for index in range(265, 269):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may1998 += prices
  avg_may1998 = total_may1998 / 4
  print(f'The average price of gas in 1998 in May is: ${avg_may1998:.2f}')

  total_jun1998 = 0
  for index in range(269, 274):
    prices = float((data[index][-5 :]))
    total_jun1998 += prices
  avg_jun1998 = total_jun1998 / 5
  print(f'The average price of gas in 1998 in June is: ${avg_jun1998:.2f}')

  total_jul1998 = 0
  for index in range(274, 278):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul1998 += prices
  avg_jul1998 = total_jul1998 / 4
  print(f'The average price of gas in 1998 in July is: ${avg_jul1998:.2f}')

  total_aug1998 = 0
  for index in range(278, 283):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug1998 += prices
  avg_aug1998 = total_aug1998 / 5
  print(f'The average price of gas in 1998 in August is: ${avg_aug1998:.2f}')

  total_sep1998 = 0
  for index in range(283, 287):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep1998 += prices
  avg_sep1998 = total_sep1998 / 4
  print(f'The average price of gas in 1998 in September is: ${avg_sep1998:.2f}')

  total_oct1998 = 0
  for index in range(287, 291):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct1998 += prices
  avg_oct1998 = total_oct1998 / 4
  print(f'The average price of gas in 1998 in October is: ${avg_oct1998:.2f}')

  total_nov1998 = 0
  for index in range(291, 296):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_nov1998 += prices
  avg_nov1998 = total_nov1998 / 5
  print(f'The average price of gas in 1998 in November is: ${avg_nov1998:.2f}')

  total_dec1998 = 0
  for index in range(296, 300):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec1998 += prices
  avg_dec1998 = total_dec1998 / 4
  print(f'The average price of gas in 1998 in December is: ${avg_dec1998:.2f}')

#1999...............................................
  
  total_jan1999 = 0
  for index in range(300, 304):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jan1999 += prices
  avg_jan1999 = total_jan1999 / 4
  print(f'The average price of gas in 1999 in January is: ${avg_jan1999:.2f}')

  total_feb1999 = 0
  for index in range(304, 308):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb1999 += prices
  avg_feb1999 = total_feb1999 / 4
  print(f'The average price of gas in 1999 in February is: ${avg_feb1999:.2f}')

  total_mar1999 = 0
  for index in range(308, 313):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar1999 += prices
  avg_mar1999 = total_mar1999 / 5
  print(f'The average price of gas in 1999 in March is: ${avg_mar1999:.2f}')

  total_apr1999 = 0
  for index in range(313, 317):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_apr1999 += prices
  avg_apr1999 = total_apr1999 / 4
  print(f'The average price of gas in 1999 in April is: ${avg_apr1999:.2f}')

  total_may1999 = 0
  for index in range(317, 322):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may1999 += prices
  avg_may1999 = total_may1999 / 5
  print(f'The average price of gas in 1999 in May is: ${avg_may1999:.2f}')

  total_jun1999 = 0
  for index in range(322, 326):
    prices = float((data[index][-5 :]))
    total_jun1999 += prices
  avg_jun1999 = total_jun1999 / 4
  print(f'The average price of gas in 1999 in June is: ${avg_jun1999:.2f}')

  total_jul1999 = 0
  for index in range(326, 330):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul1999 += prices
  avg_jul1999 = total_jul1999 / 4
  print(f'The average price of gas in 1999 in July is: ${avg_jul1999:.2f}')

  total_aug1999 = 0
  for index in range(330, 335):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug1999 += prices
  avg_aug1999 = total_aug1999 / 5
  print(f'The average price of gas in 1999 in August is: ${avg_aug1999:.2f}')

  total_sep1999 = 0
  for index in range(335, 339):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep1999 += prices
  avg_sep1999 = total_sep1999 / 4
  print(f'The average price of gas in 1999 in September is: ${avg_sep1999:.2f}')

  total_oct1999 = 0
  for index in range(339, 343):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct1999 += prices
  avg_oct1999 = total_oct1999 / 4
  print(f'The average price of gas in 1999 in October is: ${avg_oct1999:.2f}')

  total_nov1999 = 0
  for index in range(343, 348):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_nov1999 += prices
  avg_nov1999 = total_nov1999 / 5
  print(f'The average price of gas in 1999 in November is: ${avg_nov1999:.2f}')

  total_dec1999 = 0
  for index in range(348, 352):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec1999 += prices
  avg_dec1999 = total_dec1999 / 4
  print(f'The average price of gas in 1999 in December is: ${avg_dec1999:.2f}')

#2000...............................................
  
  total_jan2000 = 0
  for index in range(352, 357):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jan2000 += prices
  avg_jan2000 = total_jan2000 / 5
  print(f'The average price of gas in 2000 in January is: ${avg_jan2000:.2f}')

  total_feb2000 = 0
  for index in range(357, 361):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2000 += prices
  avg_feb2000 = total_feb2000 / 4
  print(f'The average price of gas in 2000 in February is: ${avg_feb2000:.2f}')

  total_mar2000 = 0
  for index in range(361, 365):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar2000 += prices
  avg_mar2000 = total_mar2000 / 4
  print(f'The average price of gas in 2000 in March is: ${avg_mar2000:.2f}')

  total_apr2000 = 0
  for index in range(365, 369):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_apr2000 += prices
  avg_apr2000 = total_apr2000 / 4
  print(f'The average price of gas in 2000 in April is: ${avg_apr2000:.2f}')

  total_may2000 = 0
  for index in range(369, 374):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2000 += prices
  avg_may2000 = total_may2000 / 5
  print(f'The average price of gas in 2000 in May is: ${avg_may2000:.2f}')

  total_jun2000 = 0
  for index in range(374, 378):
    prices = float((data[index][-5 :]))
    total_jun2000 += prices
  avg_jun2000 = total_jun2000 / 4
  print(f'The average price of gas in 2000 in June is: ${avg_jun2000:.2f}')

  total_jul2000 = 0
  for index in range(378, 383):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2000 += prices
  avg_jul2000 = total_jul2000 / 5
  print(f'The average price of gas in 2000 in July is: ${avg_jul2000:.2f}')

  total_aug2000 = 0
  for index in range(383, 387):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2000 += prices
  avg_aug2000 = total_aug2000 / 4
  print(f'The average price of gas in 2000 in August is: ${avg_aug2000:.2f}')

  total_sep2000 = 0
  for index in range(387, 391):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2000 += prices
  avg_sep2000 = total_sep2000 / 4
  print(f'The average price of gas in 2000 in September is: ${avg_sep2000:.2f}')

  total_oct2000 = 0
  for index in range(391, 396):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2000 += prices
  avg_oct2000 = total_oct2000 / 5
  print(f'The average price of gas in 2000 in October is: ${avg_oct2000:.2f}')

  total_nov2000 = 0
  for index in range(396, 400):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_nov2000 += prices
  avg_nov2000 = total_nov2000 / 4
  print(f'The average price of gas in 2000 in November is: ${avg_nov2000:.2f}')

  total_dec2000 = 0
  for index in range(400, 404):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2000 += prices
  avg_dec2000 = total_dec2000 / 4
  print(f'The average price of gas in 2000 in December is: ${avg_dec2000:.2f}')

#2001...............................................
  
  total_jan2001 = 0
  for index in range(404, 409):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2001 += prices
  avg_jan2001 = total_jan2001 / 5
  print(f'The average price of gas in 2001 in January is: ${avg_jan2001:.2f}')

  total_feb2001 = 0
  for index in range(409, 413):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2001 += prices
  avg_feb2001 = total_feb2001 / 4
  print(f'The average price of gas in 2001 in February is: ${avg_feb2001:.2f}')

  total_mar2001 = 0
  for index in range(413, 417):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar2001 += prices
  avg_mar2001 = total_mar2001 / 4
  print(f'The average price of gas in 2001 in March is: ${avg_mar2001:.2f}')

  total_apr2001 = 0
  for index in range(417, 422):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_apr2001 += prices
  avg_apr2001 = total_apr2001 / 5
  print(f'The average price of gas in 2001 in April is: ${avg_apr2001:.2f}')

  total_may2001 = 0
  for index in range(422, 426):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2001 += prices
  avg_may2001 = total_may2001 / 4
  print(f'The average price of gas in 2001 in May is: ${avg_may2001:.2f}')

  total_jun2001 = 0
  for index in range(426, 430):
    prices = float((data[index][-5 :]))
    total_jun2001 += prices
  avg_jun2001 = total_jun2001 / 4
  print(f'The average price of gas in 2001 in June is: ${avg_jun2001:.2f}')

  total_jul2001 = 0
  for index in range(430, 435):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2001 += prices
  avg_jul2001 = total_jul2001 / 5
  print(f'The average price of gas in 2001 in July is: ${avg_jul2001:.2f}')

  total_aug2001 = 0
  for index in range(435, 439):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2001 += prices
  avg_aug2001 = total_aug2001 / 4
  print(f'The average price of gas in 2001 in August is: ${avg_aug2001:.2f}')

  total_sep2001 = 0
  for index in range(439, 443):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2001 += prices
  avg_sep2001 = total_sep2001 / 4
  print(f'The average price of gas in 2001 in September is: ${avg_sep2001:.2f}')

  total_oct2001 = 0
  for index in range(443, 448):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2001 += prices
  avg_oct2001 = total_oct2001 / 5
  print(f'The average price of gas in 2001 in October is: ${avg_oct2001:.2f}')

  total_nov2001 = 0
  for index in range(448, 452):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_nov2001 += prices
  avg_nov2001 = total_nov2001 / 4
  print(f'The average price of gas in 2001 in November is: ${avg_nov2001:.2f}')

  total_dec2001 = 0
  for index in range(452, 457):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2001 += prices
  avg_dec2001 = total_dec2001 / 5
  print(f'The average price of gas in 2001 in December is: ${avg_dec2001:.2f}')

#2002...............................................
  
  total_jan2002 = 0
  for index in range(457, 461):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2002 += prices
  avg_jan2002 = total_jan2002 / 4
  print(f'The average price of gas in 2002 in January is: ${avg_jan2002:.2f}')

  total_feb2002 = 0
  for index in range(461, 465):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2002 += prices
  avg_feb2002 = total_feb2002 / 4
  print(f'The average price of gas in 2002 in February is: ${avg_feb2002:.2f}')

  total_mar2002 = 0
  for index in range(465, 469):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar2002 += prices
  avg_mar2002 = total_mar2002 / 4
  print(f'The average price of gas in 2002 in March is: ${avg_mar2002:.2f}')

  total_apr2002 = 0
  for index in range(469, 474):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_apr2002 += prices
  avg_apr2002 = total_apr2002 / 5
  print(f'The average price of gas in 2002 in April is: ${avg_apr2002:.2f}')

  total_may2002 = 0
  for index in range(474, 478):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2002 += prices
  avg_may2002 = total_may2002 / 4
  print(f'The average price of gas in 2002 in May is: ${avg_may2002:.2f}')

  total_jun2002 = 0
  for index in range(478, 482):
    prices = float((data[index][-5 :]))
    total_jun2002 += prices
  avg_jun2002 = total_jun2002 / 4
  print(f'The average price of gas in 2002 in June is: ${avg_jun2002:.2f}')

  total_jul2002 = 0
  for index in range(482, 487):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2002 += prices
  avg_jul2002 = total_jul2002 / 5
  print(f'The average price of gas in 2002 in July is: ${avg_jul2002:.2f}')

  total_aug2002 = 0
  for index in range(487, 491):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2002 += prices
  avg_aug2002 = total_aug2002 / 4
  print(f'The average price of gas in 2002 in August is: ${avg_aug2002:.2f}')

  total_sep2002 = 0
  for index in range(491, 496):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2002 += prices
  avg_sep2002 = total_sep2002 / 5
  print(f'The average price of gas in 2002 in September is: ${avg_sep2002:.2f}')

  total_oct2002 = 0
  for index in range(496, 500):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2002 += prices
  avg_oct2002 = total_oct2002 / 4
  print(f'The average price of gas in 2002 in October is: ${avg_oct2002:.2f}')

  total_nov2002 = 0
  for index in range(500, 504):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_nov2002 += prices
  avg_nov2002 = total_nov2002 / 4
  print(f'The average price of gas in 2002 in November is: ${avg_nov2002:.2f}')

  total_dec2002 = 0
  for index in range(504, 509):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2002 += prices
  avg_dec2002 = total_dec2002 / 5
  print(f'The average price of gas in 2002 in December is: ${avg_dec2002:.2f}')

#2003...............................................
  
  total_jan2003 = 0
  for index in range(509, 513):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2003 += prices
  avg_jan2003 = total_jan2003 / 4
  print(f'The average price of gas in 2003 in January is: ${avg_jan2003:.2f}')

  total_feb2003 = 0
  for index in range(513, 517):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2003 += prices
  avg_feb2003 = total_feb2003 / 4
  print(f'The average price of gas in 2003 in February is: ${avg_feb2003:.2f}')

  total_mar2003 = 0
  for index in range(517, 522):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_mar2003 += prices
  avg_mar2003 = total_mar2003 / 5
  print(f'The average price of gas in 2003 in March is: ${avg_mar2003:.2f}')

  total_apr2003 = 0
  for index in range(522, 526):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2003 += prices
  avg_apr2003 = total_apr2003 / 4
  print(f'The average price of gas in 2003 in April is: ${avg_apr2003:.2f}')

  total_may2003 = 0
  for index in range(526, 530):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2003 += prices
  avg_may2003 = total_may2003 / 4
  print(f'The average price of gas in 2003 in May is: ${avg_may2003:.2f}')

  total_jun2003 = 0
  for index in range(530, 535):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jun2003 += prices
  avg_jun2003 = total_jun2003 / 5
  print(f'The average price of gas in 2003 in June is: ${avg_jun2003:.2f}')

  total_jul2003 = 0
  for index in range(535, 539):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2003 += prices
  avg_jul2003 = total_jul2003 / 4
  print(f'The average price of gas in 2003 in July is: ${avg_jul2003:.2f}')

  total_aug2003 = 0
  for index in range(539, 543):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2003 += prices
  avg_aug2003 = total_aug2003 / 4
  print(f'The average price of gas in 2003 in August is: ${avg_aug2003:.2f}')

  total_sep2003 = 0
  for index in range(543, 548):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2003 += prices
  avg_sep2003 = total_sep2003 / 5
  print(f'The average price of gas in 2003 in September is: ${avg_sep2003:.2f}')

  total_oct2003 = 0
  for index in range(548, 552):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2003 += prices
  avg_oct2003 = total_oct2003 / 4
  print(f'The average price of gas in 2003 in October is: ${avg_oct2003:.2f}')

  total_nov2003 = 0
  for index in range(552, 556):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_nov2003 += prices
  avg_nov2003 = total_nov2003 / 4
  print(f'The average price of gas in 2003 in November is: ${avg_nov2003:.2f}')

  total_dec2003 = 0
  for index in range(556, 561):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2003 += prices
  avg_dec2003 = total_dec2003 / 5
  print(f'The average price of gas in 2003 in December is: ${avg_dec2003:.2f}')

#2004...............................................
  
  total_jan2004 = 0
  for index in range(561, 565):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2004 += prices
  avg_jan2004 = total_jan2004 / 4
  print(f'The average price of gas in 2004 in January is: ${avg_jan2004:.2f}')

  total_feb2004 = 0
  for index in range(565, 569):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2004 += prices
  avg_feb2004 = total_feb2004 / 4
  print(f'The average price of gas in 2004 in February is: ${avg_feb2004:.2f}')

  total_mar2004 = 0
  for index in range(569, 574):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2004 += prices
  avg_mar2004 = total_mar2004 / 5
  print(f'The average price of gas in 2004 in March is: ${avg_mar2004:.2f}')

  total_apr2004 = 0
  for index in range(574, 578):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2004 += prices
  avg_apr2004 = total_apr2004 / 4
  print(f'The average price of gas in 2004 in April is: ${avg_apr2004:.2f}')

  total_may2004 = 0
  for index in range(578, 583):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2004 += prices
  avg_may2004 = total_may2004 / 5
  print(f'The average price of gas in 2004 in May is: ${avg_may2004:.2f}')

  total_jun2004 = 0
  for index in range(583, 587):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jun2004 += prices
  avg_jun2004 = total_jun2004 / 4
  print(f'The average price of gas in 2004 in June is: ${avg_jun2004:.2f}')

  total_jul2004 = 0
  for index in range(587, 591):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2004 += prices
  avg_jul2004 = total_jul2004 / 4
  print(f'The average price of gas in 2004 in July is: ${avg_jul2004:.2f}')

  total_aug2004 = 0
  for index in range(591, 596):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2004 += prices
  avg_aug2004 = total_aug2004 / 5
  print(f'The average price of gas in 2004 in August is: ${avg_aug2004:.2f}')

  total_sep2004 = 0
  for index in range(596, 600):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2004 += prices
  avg_sep2004 = total_sep2004 / 4
  print(f'The average price of gas in 2004 in September is: ${avg_sep2004:.2f}')

  total_oct2004 = 0
  for index in range(600, 604):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2004 += prices
  avg_oct2004 = total_oct2004 / 4
  print(f'The average price of gas in 2004 in October is: ${avg_oct2004:.2f}')

  total_nov2004 = 0
  for index in range(604, 609):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_nov2004 += prices
  avg_nov2004 = total_nov2004 / 5
  print(f'The average price of gas in 2004 in November is: ${avg_nov2004:.2f}')

  total_dec2004 = 0
  for index in range(609, 613):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2004 += prices
  avg_dec2004 = total_dec2004 / 4
  print(f'The average price of gas in 2004 in December is: ${avg_dec2004:.2f}')

#2005...............................................
  
  total_jan2005 = 0
  for index in range(613, 618):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2005 += prices
  avg_jan2005 = total_jan2005 / 5
  print(f'The average price of gas in 2005 in January is: ${avg_jan2005:.2f}')

  total_feb2005 = 0
  for index in range(618, 622):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2005 += prices
  avg_feb2005 = total_feb2005 / 4
  print(f'The average price of gas in 2005 in February is: ${avg_feb2005:.2f}')

  total_mar2005 = 0
  for index in range(622, 626):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2005 += prices
  avg_mar2005 = total_mar2005 / 4
  print(f'The average price of gas in 2005 in March is: ${avg_mar2005:.2f}')

  total_apr2005 = 0
  for index in range(626, 630):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2005 += prices
  avg_apr2005 = total_apr2005 / 4
  print(f'The average price of gas in 2005 in April is: ${avg_apr2005:.2f}')

  total_may2005 = 0
  for index in range(630, 635):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2005 += prices
  avg_may2005 = total_may2005 / 5
  print(f'The average price of gas in 2005 in May is: ${avg_may2005:.2f}')

  total_jun2005 = 0
  for index in range(635, 639):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jun2005 += prices
  avg_jun2005 = total_jun2005 / 4
  print(f'The average price of gas in 2005 in June is: ${avg_jun2005:.2f}')

  total_jul2005 = 0
  for index in range(639, 643):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2005 += prices
  avg_jul2005 = total_jul2005 / 4
  print(f'The average price of gas in 2005 in July is: ${avg_jul2005:.2f}')

  total_aug2005 = 0
  for index in range(643, 648):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2005 += prices
  avg_aug2005 = total_aug2005 / 5
  print(f'The average price of gas in 2005 in August is: ${avg_aug2005:.2f}')

  total_sep2005 = 0
  for index in range(648, 652):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2005 += prices
  avg_sep2005 = total_sep2005 / 4
  print(f'The average price of gas in 2005 in September is: ${avg_sep2005:.2f}')

  total_oct2005 = 0
  for index in range(652, 657):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2005 += prices
  avg_oct2005 = total_oct2005 / 5
  print(f'The average price of gas in 2005 in October is: ${avg_oct2005:.2f}')

  total_nov2005 = 0
  for index in range(657, 661):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2005 += prices
  avg_nov2005 = total_nov2005 / 4
  print(f'The average price of gas in 2005 in November is: ${avg_nov2005:.2f}')

  total_dec2005 = 0
  for index in range(661, 665):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2005 += prices
  avg_dec2005 = total_dec2005 / 4
  print(f'The average price of gas in 2005 in December is: ${avg_dec2005:.2f}')

#2006...............................................
  
  total_jan2006 = 0
  for index in range(665, 670):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2006 += prices
  avg_jan2006 = total_jan2006 / 5
  print(f'The average price of gas in 2006 in January is: ${avg_jan2006:.2f}')

  total_feb2006 = 0
  for index in range(670, 674):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2006 += prices
  avg_feb2006 = total_feb2006 / 4
  print(f'The average price of gas in 2006 in February is: ${avg_feb2006:.2f}')

  total_mar2006 = 0
  for index in range(674, 678):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2006 += prices
  avg_mar2006 = total_mar2006 / 4
  print(f'The average price of gas in 2006 in March is: ${avg_mar2006:.2f}')

  total_apr2006 = 0
  for index in range(678, 682):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2006 += prices
  avg_apr2006 = total_apr2006 / 4
  print(f'The average price of gas in 2006 in April is: ${avg_apr2006:.2f}')

  total_may2006 = 0
  for index in range(682, 687):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2006 += prices
  avg_may2006 = total_may2006 / 5
  print(f'The average price of gas in 2006 in May is: ${avg_may2006:.2f}')

  total_jun2006 = 0
  for index in range(687, 691):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_jun2006 += prices
  avg_jun2006 = total_jun2006 / 4
  print(f'The average price of gas in 2006 in June is: ${avg_jun2006:.2f}')

  total_jul2006 = 0
  for index in range(691, 696):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2006 += prices
  avg_jul2006 = total_jul2006 / 5
  print(f'The average price of gas in 2006 in July is: ${avg_jul2006:.2f}')

  total_aug2006 = 0
  for index in range(696, 700):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2006 += prices
  avg_aug2006 = total_aug2006 / 4
  print(f'The average price of gas in 2006 in August is: ${avg_aug2006:.2f}')

  total_sep2006 = 0
  for index in range(700, 704):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2006 += prices
  avg_sep2006 = total_sep2006 / 4
  print(f'The average price of gas in 2006 in September is: ${avg_sep2006:.2f}')

  total_oct2006 = 0
  for index in range(704, 709):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2006 += prices
  avg_oct2006 = total_oct2006 / 5
  print(f'The average price of gas in 2006 in October is: ${avg_oct2006:.2f}')

  total_nov2006 = 0
  for index in range(709, 713):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2006 += prices
  avg_nov2006 = total_nov2006 / 4
  print(f'The average price of gas in 2006 in November is: ${avg_nov2006:.2f}')

  total_dec2006 = 0
  for index in range(713, 717):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2006 += prices
  avg_dec2006 = total_dec2006 / 4
  print(f'The average price of gas in 2006 in December is: ${avg_dec2006:.2f}')

#2007...............................................
  
  total_jan2007 = 0
  for index in range(717, 722):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2007 += prices
  avg_jan2007 = total_jan2007 / 5
  print(f'The average price of gas in 2007 in January is: ${avg_jan2007:.2f}')

  total_feb2007 = 0
  for index in range(722, 726):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2007 += prices
  avg_feb2007 = total_feb2007 / 4
  print(f'The average price of gas in 2007 in February is: ${avg_feb2007:.2f}')

  total_mar2007 = 0
  for index in range(726, 730):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2007 += prices
  avg_mar2007 = total_mar2007 / 4
  print(f'The average price of gas in 2007 in March is: ${avg_mar2007:.2f}')

  total_apr2007 = 0
  for index in range(730, 735):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2007 += prices
  avg_apr2007 = total_apr2007 / 5
  print(f'The average price of gas in 2007 in April is: ${avg_apr2007:.2f}')

  total_may2007 = 0
  for index in range(735, 739):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2007 += prices
  avg_may2007 = total_may2007 / 4
  print(f'The average price of gas in 2007 in May is: ${avg_may2007:.2f}')

  total_jun2007 = 0
  for index in range(739, 743):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jun2007 += prices
  avg_jun2007 = total_jun2007 / 4
  print(f'The average price of gas in 2007 in June is: ${avg_jun2007:.2f}')

  total_jul2007 = 0
  for index in range(743, 748):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2007 += prices
  avg_jul2007 = total_jul2007 / 5
  print(f'The average price of gas in 2007 in July is: ${avg_jul2007:.2f}')

  total_aug2007 = 0
  for index in range(748, 752):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2007 += prices
  avg_aug2007 = total_aug2007 / 4
  print(f'The average price of gas in 2007 in August is: ${avg_aug2007:.2f}')

  total_sep2007 = 0
  for index in range(752, 756):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2007 += prices
  avg_sep2007 = total_sep2007 / 4
  print(f'The average price of gas in 2007 in September is: ${avg_sep2007:.2f}')

  total_oct2007 = 0
  for index in range(756, 761):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2007 += prices
  avg_oct2007 = total_oct2007 / 5
  print(f'The average price of gas in 2007 in October is: ${avg_oct2007:.2f}')

  total_nov2007 = 0
  for index in range(761, 765):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2007 += prices
  avg_nov2007 = total_nov2007 / 4
  print(f'The average price of gas in 2007 in November is: ${avg_nov2007:.2f}')

  total_dec2007 = 0
  for index in range(765, 770):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2007 += prices
  avg_dec2007 = total_dec2007 / 5
  print(f'The average price of gas in 2007 in December is: ${avg_dec2007:.2f}')

#2008...............................................
  
  total_jan2008 = 0
  for index in range(770, 774):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2008 += prices
  avg_jan2008 = total_jan2008 / 4
  print(f'The average price of gas in 2008 in January is: ${avg_jan2008:.2f}')

  total_feb2008 = 0
  for index in range(774, 778):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2008 += prices
  avg_feb2008 = total_feb2008 / 4
  print(f'The average price of gas in 2008 in February is: ${avg_feb2008:.2f}')

  total_mar2008 = 0
  for index in range(778, 783):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2008 += prices
  avg_mar2008 = total_mar2008 / 5
  print(f'The average price of gas in 2008 in March is: ${avg_mar2008:.2f}')

  total_apr2008 = 0
  for index in range(783, 787):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2008 += prices
  avg_apr2008 = total_apr2008 / 4
  print(f'The average price of gas in 2008 in April is: ${avg_apr2008:.2f}')

  total_may2008 = 0
  for index in range(787, 791):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2008 += prices
  avg_may2008 = total_may2008 / 4
  print(f'The average price of gas in 2008 in May is: ${avg_may2008:.2f}')

  total_jun2008 = 0
  for index in range(791, 796):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jun2008 += prices
  avg_jun2008 = total_jun2008 / 5
  print(f'The average price of gas in 2008 in June is: ${avg_jun2008:.2f}')

  total_jul2008 = 0
  for index in range(796, 800):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2008 += prices
  avg_jul2008 = total_jul2008 / 4
  print(f'The average price of gas in 2008 in July is: ${avg_jul2008:.2f}')

  total_aug2008 = 0
  for index in range(800, 804):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_aug2008 += prices
  avg_aug2008 = total_aug2008 / 4
  print(f'The average price of gas in 2008 in August is: ${avg_aug2008:.2f}')

  total_sep2008 = 0
  for index in range(804, 809):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2008 += prices
  avg_sep2008 = total_sep2008 / 5
  print(f'The average price of gas in 2008 in September is: ${avg_sep2008:.2f}')

  total_oct2008 = 0
  for index in range(809, 813):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2008 += prices
  avg_oct2008 = total_oct2008 / 4
  print(f'The average price of gas in 2008 in October is: ${avg_oct2008:.2f}')

  total_nov2008 = 0
  for index in range(813, 817):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2008 += prices
  avg_nov2008 = total_nov2008 / 4
  print(f'The average price of gas in 2008 in November is: ${avg_nov2008:.2f}')

  total_dec2008 = 0
  for index in range(817, 822):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2008 += prices
  avg_dec2008 = total_dec2008 / 5
  print(f'The average price of gas in 2008 in December is: ${avg_dec2008:.2f}')

#2009...............................................
  
  total_jan2009 = 0
  for index in range(822, 826):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2009 += prices
  avg_jan2009 = total_jan2009 / 4
  print(f'The average price of gas in 2009 in January is: ${avg_jan2009:.2f}')

  total_feb2009 = 0
  for index in range(826, 830):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2009 += prices
  avg_feb2009 = total_feb2009 / 4
  print(f'The average price of gas in 2009 in February is: ${avg_feb2009:.2f}')

  total_mar2009 = 0
  for index in range(830, 835):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2009 += prices
  avg_mar2009 = total_mar2009 / 5
  print(f'The average price of gas in 2009 in March is: ${avg_mar2009:.2f}')

  total_apr2009 = 0
  for index in range(835, 839):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2009 += prices
  avg_apr2009 = total_apr2009 / 4
  print(f'The average price of gas in 2009 in April is: ${avg_apr2009:.2f}')

  total_may2009 = 0
  for index in range(839, 843):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2009 += prices
  avg_may2009 = total_may2009 / 4
  print(f'The average price of gas in 2009 in May is: ${avg_may2009:.2f}')

  total_jun2009 = 0
  for index in range(843, 848):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jun2009 += prices
  avg_jun2009 = total_jun2009 / 5
  print(f'The average price of gas in 2009 in June is: ${avg_jun2009:.2f}')

  total_jul2009 = 0
  for index in range(848, 852):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2009 += prices
  avg_jul2009 = total_jul2009 / 4
  print(f'The average price of gas in 2009 in July is: ${avg_jul2009:.2f}')

  total_aug2009 = 0
  for index in range(852, 857):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_aug2009 += prices
  avg_aug2009 = total_aug2009 / 5
  print(f'The average price of gas in 2009 in August is: ${avg_aug2009:.2f}')

  total_sep2009 = 0
  for index in range(857, 861):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2009 += prices
  avg_sep2009 = total_sep2009 / 4
  print(f'The average price of gas in 2009 in September is: ${avg_sep2009:.2f}')

  total_oct2009 = 0
  for index in range(861, 865):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2009 += prices
  avg_oct2009 = total_oct2009 / 4
  print(f'The average price of gas in 2009 in October is: ${avg_oct2009:.2f}')

  total_nov2009 = 0
  for index in range(865, 870):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2009 += prices
  avg_nov2009 = total_nov2009 / 5
  print(f'The average price of gas in 2009 in November is: ${avg_nov2009:.2f}')

  total_dec2009 = 0
  for index in range(870, 874):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2009 += prices
  avg_dec2009 = total_dec2009 / 4
  print(f'The average price of gas in 2009 in December is: ${avg_dec2009:.2f}')

#2010...............................................
  
  total_jan2010 = 0
  for index in range(874, 878):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2010 += prices
  avg_jan2010 = total_jan2010 / 4
  print(f'The average price of gas in 2010 in January is: ${avg_jan2010:.2f}')

  total_feb2010 = 0
  for index in range(878, 882):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2010 += prices
  avg_feb2010 = total_feb2010 / 4
  print(f'The average price of gas in 2010 in February is: ${avg_feb2010:.2f}')

  total_mar2010 = 0
  for index in range(882, 887):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2010 += prices
  avg_mar2010 = total_mar2010 / 5
  print(f'The average price of gas in 2010 in March is: ${avg_mar2010:.2f}')

  total_apr2010 = 0
  for index in range(887, 891):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2010 += prices
  avg_apr2010 = total_apr2010 / 4
  print(f'The average price of gas in 2010 in April is: ${avg_apr2010:.2f}')

  total_may2010 = 0
  for index in range(891, 896):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2010 += prices
  avg_may2010 = total_may2010 / 5
  print(f'The average price of gas in 2010 in May is: ${avg_may2010:.2f}')

  total_jun2010 = 0
  for index in range(896, 900):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jun2010 += prices
  avg_jun2010 = total_jun2010 / 4
  print(f'The average price of gas in 2010 in June is: ${avg_jun2010:.2f}')

  total_jul2010 = 0
  for index in range(900, 904):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2010 += prices
  avg_jul2010 = total_jul2010 / 4
  print(f'The average price of gas in 2010 in July is: ${avg_jul2010:.2f}')

  total_aug2010 = 0
  for index in range(904, 909):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_aug2010 += prices
  avg_aug2010 = total_aug2010 / 5
  print(f'The average price of gas in 2010 in August is: ${avg_aug2010:.2f}')

  total_sep2010 = 0
  for index in range(909, 913):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2010 += prices
  avg_sep2010 = total_sep2010 / 4
  print(f'The average price of gas in 2010 in September is: ${avg_sep2010:.2f}')

  total_oct2010 = 0
  for index in range(913, 917):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2010 += prices
  avg_oct2010 = total_oct2010 / 4
  print(f'The average price of gas in 2010 in October is: ${avg_oct2010:.2f}')

  total_nov2010 = 0
  for index in range(917, 922):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2010 += prices
  avg_nov2010 = total_nov2010 / 5
  print(f'The average price of gas in 2010 in November is: ${avg_nov2010:.2f}')

  total_dec2010 = 0
  for index in range(922, 926):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2010 += prices
  avg_dec2010 = total_dec2010 / 4
  print(f'The average price of gas in 2010 in December is: ${avg_dec2010:.2f}')

#2011...............................................
  
  total_jan2011 = 0
  for index in range(926, 931):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2011 += prices
  avg_jan2011 = total_jan2011 / 5
  print(f'The average price of gas in 2011 in January is: ${avg_jan2011:.2f}')

  total_feb2011 = 0
  for index in range(931, 935):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2011 += prices
  avg_feb2011 = total_feb2011 / 4
  print(f'The average price of gas in 2011 in February is: ${avg_feb2011:.2f}')

  total_mar2011 = 0
  for index in range(935, 939):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2011 += prices
  avg_mar2011 = total_mar2011 / 4
  print(f'The average price of gas in 2011 in March is: ${avg_mar2011:.2f}')

  total_apr2011 = 0
  for index in range(939, 943):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2011 += prices
  avg_apr2011 = total_apr2011 / 4
  print(f'The average price of gas in 2011 in April is: ${avg_apr2011:.2f}')

  total_may2011 = 0
  for index in range(943, 948):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2011 += prices
  avg_may2011 = total_may2011 / 5
  print(f'The average price of gas in 2011 in May is: ${avg_may2011:.2f}')

  total_jun2011 = 0
  for index in range(948, 952):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jun2011 += prices
  avg_jun2011 = total_jun2011 / 4
  print(f'The average price of gas in 2011 in June is: ${avg_jun2011:.2f}')

  total_jul2011 = 0
  for index in range(952, 956):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2011 += prices
  avg_jul2011 = total_jul2011 / 4
  print(f'The average price of gas in 2011 in July is: ${avg_jul2011:.2f}')

  total_aug2011 = 0
  for index in range(956, 961):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_aug2011 += prices
  avg_aug2011 = total_aug2011 / 5
  print(f'The average price of gas in 2011 in August is: ${avg_aug2011:.2f}')

  total_sep2011 = 0
  for index in range(961, 965):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2011 += prices
  avg_sep2011 = total_sep2011 / 4
  print(f'The average price of gas in 2011 in September is: ${avg_sep2011:.2f}')

  total_oct2011 = 0
  for index in range(965, 970):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2011 += prices
  avg_oct2011 = total_oct2011 / 5
  print(f'The average price of gas in 2011 in October is: ${avg_oct2011:.2f}')

  total_nov2011 = 0
  for index in range(970, 974):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2011 += prices
  avg_nov2011 = total_nov2011 / 4
  print(f'The average price of gas in 2011 in November is: ${avg_nov2011:.2f}')

  total_dec2011 = 0
  for index in range(974, 978):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2011 += prices
  avg_dec2011 = total_dec2011 / 4
  print(f'The average price of gas in 2011 in December is: ${avg_dec2011:.2f}')

#2012...............................................
  
  total_jan2012 = 0
  for index in range(978, 983):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2012 += prices
  avg_jan2012 = total_jan2012 / 5
  print(f'The average price of gas in 2012 in January is: ${avg_jan2012:.2f}')

  total_feb2012 = 0
  for index in range(983, 987):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2012 += prices
  avg_feb2012 = total_feb2012 / 4
  print(f'The average price of gas in 2012 in February is: ${avg_feb2012:.2f}')

  total_mar2012 = 0
  for index in range(987, 991):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2012 += prices
  avg_mar2012 = total_mar2012 / 4
  print(f'The average price of gas in 2012 in March is: ${avg_mar2012:.2f}')

  total_apr2012 = 0
  for index in range(991, 996):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2012 += prices
  avg_apr2012 = total_apr2012 / 5
  print(f'The average price of gas in 2012 in April is: ${avg_apr2012:.2f}')

  total_may2012 = 0
  for index in range(996, 1000):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2012 += prices
  avg_may2012 = total_may2012 / 4
  print(f'The average price of gas in 2012 in May is: ${avg_may2012:.2f}')

  total_jun2012 = 0
  for index in range(1000, 1004):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jun2012 += prices
  avg_jun2012 = total_jun2012 / 4
  print(f'The average price of gas in 2012 in June is: ${avg_jun2012:.2f}')

  total_jul2012 = 0
  for index in range(1004, 1009):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2012 += prices
  avg_jul2012 = total_jul2012 / 5
  print(f'The average price of gas in 2012 in July is: ${avg_jul2012:.2f}')

  total_aug2012 = 0
  for index in range(1009, 1013):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_aug2012 += prices
  avg_aug2012 = total_aug2012 / 4
  print(f'The average price of gas in 2012 in August is: ${avg_aug2012:.2f}')

  total_sep2012 = 0
  for index in range(1013, 1017):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_sep2012 += prices
  avg_sep2012 = total_sep2012 / 4
  print(f'The average price of gas in 2012 in September is: ${avg_sep2012:.2f}')

  total_oct2012 = 0
  for index in range(1017, 1022):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_oct2012 += prices
  avg_oct2012 = total_oct2012 / 5
  print(f'The average price of gas in 2012 in October is: ${avg_oct2012:.2f}')

  total_nov2012 = 0
  for index in range(1022, 1026):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_nov2012 += prices
  avg_nov2012 = total_nov2012 / 4
  print(f'The average price of gas in 2012 in November is: ${avg_nov2012:.2f}')

  total_dec2012 = 0
  for index in range(1026, 1031):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_dec2012 += prices
  avg_dec2012 = total_dec2012 / 5
  print(f'The average price of gas in 2012 in December is: ${avg_dec2012:.2f}')

#2013...............................................
  
  total_jan2013 = 0
  for index in range(1031, 1035):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jan2013 += prices
  avg_jan2013 = total_jan2013 / 4
  print(f'The average price of gas in 2013 in January is: ${avg_jan2013:.2f}')

  total_feb2013 = 0
  for index in range(1035, 1039):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_feb2013 += prices
  avg_feb2013 = total_feb2013 / 4
  print(f'The average price of gas in 2013 in February is: ${avg_feb2013:.2f}')

  total_mar2013 = 0
  for index in range(1039, 1043):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_mar2013 += prices
  avg_mar2013 = total_mar2013 / 4
  print(f'The average price of gas in 2013 in March is: ${avg_mar2013:.2f}')

  total_apr2013 = 0
  for index in range(1043, 1048):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_apr2013 += prices
  avg_apr2013 = total_apr2013 / 5
  print(f'The average price of gas in 2013 in April is: ${avg_apr2013:.2f}')

  total_may2013 = 0
  for index in range(1048, 1052):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    else:
      prices = float(data[index][-4 :])
    total_may2013 += prices
  avg_may2013 = total_may2013 / 4
  print(f'The average price of gas in 2013 in May is: ${avg_may2013:.2f}')

  total_jun2013 = 0
  for index in range(1052, 1056):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jun2013 += prices
  avg_jun2013 = total_jun2013 / 4
  print(f'The average price of gas in 2013 in June is: ${avg_jun2013:.2f}')

  total_jul2013 = 0
  for index in range(1056, 1061):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_jul2013 += prices
  avg_jul2013 = total_jul2013 / 5
  print(f'The average price of gas in 2013 in July is: ${avg_jul2013:.2f}')

  total_aug2013 = 0
  for index in range(1061, 1065):
    if len(data[index]) == 16:
      prices = float(data[index][-5 :])
    elif len(data[index]) == 15:
      prices = float(data[index][-4 :])
    else:
      prices = float(data[index][-3 :])
    total_aug2013 += prices
  avg_aug2013 = total_aug2013 / 4
  print(f'The average price of gas in 2013 in August is: ${avg_aug2013:.2f}\n')

def lowtohigh_price(split_data, prices):

  print('List of Lowest to Higest Prices...\n')
  
  prices.sort()
  for num in range(0, 1065, 5):
    for index in range(1065):
      if prices[num] == split_data[index][1]:
        print(f'Date: {split_data[index][0]}, price: ${prices[num]}')

def hightolow_price(split_data, prices):

  print()
  print('List of Highest to Lowest Prices...\n')
  
  prices.sort()
  prices.reverse()
  for num in range(0, 1065, 5):
    for index in range(1065):
      if prices[num] == split_data[index][1]:
        print(f'Date: {split_data[index][0]}, price: ${prices[num]}')

main()