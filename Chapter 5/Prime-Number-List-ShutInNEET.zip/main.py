'''
Chapter 5 Exercise 18
Jake Schrecengost

This program displays all the prime numbers from 1 to 100. The program has a loop thats called the isPrime function.

Inputs: n/a
Constants: n/a
Outputs: Prime numbers 1-100
'''

def main():
  print('Prime numbers 1-100')
  print('-------------------')
  isPrime()
    
def isPrime():
  for num in range(1, 10):
    if num == 2 or num == 3 or num == 5 or num == 7:
      print(num)
    else:
      pass

  for num in range(11, 101):
    if num % 2 != 0 and num % 3 != 0 and num % 5 != 0 and num % 7 != 0:
      print(num)
    else:
      pass

main()