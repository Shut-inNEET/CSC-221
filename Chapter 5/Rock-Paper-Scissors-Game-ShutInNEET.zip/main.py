'''
Chapter 5 Exercise 21
Jake Schrecengost

This program lets the user play the game of Rock, Paper, Scissors against the computer. The game consists of a loop (called the game loop) where several rounds (called matches) are played. The play for the matches works like this:
1. The user enters his or her choice of “rock,” “paper,” “scissors”, or “quit” at the keyboard.
2. The computer selects a random number in the range of 1 through 3. If the number is 1, then the computer has chosen rock. If the number is 2, then the computer has chosen paper. If the number is 3, then the computer has chosen scissors.
3. The computer’s choice is displayed.
4. A match winner is selected according to the following rules:
  - If one player chooses rock and the other player chooses scissors,         then rock wins. (Rock smashes scissors.)
  - If one player chooses scissors and the other player chooses paper, 
    then scissors wins. (Scissors cuts paper.)
  - If one player chooses paper and the other player chooses rock, then 
    paper wins. (Paper wraps rock.)
  - If both players make the same choice, the game must be played again 
    to determine the winner.
The game loop continues with matches until the user decides to quit. Within the game loop the number of matches won by the computer and the human player is tracked (note that a match could end in a draw in which case neither the player nor the computer gets a point). When the player decides to quit, the game loop is terminated, and the program displays the final scores and writes a message declaring the winner of the tournament (or declares a draw if the scores are the same).

Inputs: rock, paper, scissors, or quit
Constants: rock > scissors, paper > rock, scissors > paper
Outputs: user score, computer score, winner of the tournament, or draw
'''
import random

def main():

  game_loop = 0 
  user = 0 
  computer = 0
  while game_loop != 'quit': 

    user_answer = 0
    while user_input(user_answer):
      print('Please enter rock, paper, scissors, or quit.') 
      user_answer = str(input('Enter a valid answer: ')) 
    
    computer_answer = computer_input(user_answer)

    score = calc_score(user_answer, computer_answer)

    if score == 1:
      user = user + 1
    elif score == 0:
      computer = computer + 1
    else:
      pass
    print (f'computer points:{computer}\tuser points:{user}')

    game_loop = user_answer

  determine_winner(user, computer)

def user_input(answer):
  if answer != 'rock' and answer != 'paper' and answer != 'scissors' and answer != 'quit':
    status = True
  else:
    status = False
  return status

def computer_input(answer):
  if answer == 'quit':
    pass
  else:
    computer_answer = random.randint(1, 3)
    if computer_answer == 1:
      computer_answer = 'rock'
      print('Computer chooses rock')
    elif computer_answer == 2:
      computer_answer = 'paper'
      print('Computer chooses paper')
    elif computer_answer == 3:
      computer_answer = 'scissors'
      print('Computer chooses scissors')
    return computer_answer

def calc_score(user, computer):
  if user == 'rock' and computer == 'scissors':
    print('You won!')
    score = 1
    return score
  elif user == 'paper' and computer == 'rock':
    print('You won!')
    score = 1
    return score
  elif user == 'scissors' and computer == 'paper':
    print('You won!')
    score = 1
    return score
  elif user == computer:
    print('Draw!')
  elif user == 'quit':
    pass
  else:
    print('Computer won!')
    score = 0
    return score

def determine_winner(user, computer):
  if user > computer:
    print('You won the tournament!')
  elif user < computer:
    print('Computer won the tournament!')
  else:
    print('The tournament ended in a draw!')

main()