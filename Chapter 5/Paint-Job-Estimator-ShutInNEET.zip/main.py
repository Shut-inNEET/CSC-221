'''
Chapter 5 Exercise 8
Jake Schrecengost

A painting company has determined that for every 112 square feet of wall space, one gallon of paint and eight hours of labor will be required. The company charges $35.00 per hour for labor. This program asks the user to enter the square feet of wall space to be painted and the price of the paint per gallon. The program should display the following data: number of gallons of paint required, hours of labor required, cost of the paint, labor charges, and total cost of the paint job. 

Inputs: Square feet of wall space, Price of paint per gallon
Constants: Price per hour of labor
Outputs: Number of gallons of paint required, Hours of labor required, Cost of the paint, Labor charges, and Total cost of the paint job
'''
priceperhour_labor = 35

def main():
  wall_space, paint_pricepergal = get_input()
  total_gallonsofpaint(wall_space)
  total_hours(wall_space)
  paintcost = total_paintcost(wall_space, paint_pricepergal)
  total_laborcharges = labor_charge(wall_space)
  print(f'Total cost of the paint job is ${paintcost + total_laborcharges:.2f}')

def get_input():
  wall_space = float(input('How many square feet of wall space need to be painted? '))
  paint_pricepergal = float(input('What is the price of the paint per gallon? $'))
  return wall_space, paint_pricepergal

def total_gallonsofpaint(area):
  total_required = area / 112
  print(f'Number of gallons of paint required is {total_required:.2f}')

def total_hours(area):
  total_required = (area / 112) * 8
  print(f'Number of hours required is {total_required:.2f}')

def total_paintcost(area, price):
  total_gallons = area / 112
  paintcost = total_gallons * price
  print(f'The total cost of the paint is ${paintcost:.2f}')
  return paintcost
  
def labor_charge(area):
  hours = (area / 112) * 8
  total_laborcharges = hours * priceperhour_labor
  print(f'Total labor charge is ${total_laborcharges:.2f}')
  return total_laborcharges

main()