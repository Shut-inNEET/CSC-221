'''
Chapter 5 Exercise 17
Jake Schrecengost

This program uses a Boolean function named isPrime which takes an integer as an argument and returns true if the 
argument is a prime number, or false otherwise. The function in this program prompts the user to enter a number then displays a message indicating whether the number is prime.

Inputs: number
Constants: n/a
Outputs: Prime, Not a prime number
'''

def main():
  number = int(input('Please input a random number: '))
  if isPrime(number):
    print('The number is prime')
  else:
    print('The number is not prime')
    

def isPrime(num):
  if num <= 10:
    if num == 2 or num == 3 or num == 5 or num == 7:
      status = True
    else:
      status = False

  elif num > 10:
    if num % 2 != 0 and num % 3 != 0 and num % 5 != 0 and num % 7 != 0:
      status = True
    else:
      status = False

  return status

main()