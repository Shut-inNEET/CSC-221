'''
Chapter 5 Exercise 7
Jake Schrecengost

There are three seating categories at a stadium. Class A seats cost $20, Class B seats cost $15, and Class C seats cost $10. This program asks how many tickets for each class of seats were sold, then displays the amount of income generated from ticket sales. The program includes a function that takes the cost of a single ticket and the number of tickets sold at that cost and returns the amount of money received from the tickets sold at that cost.

Inputs: Tickets A, Tickets B, Tickets C sold
Constants: Class A, Class B, Class C price
Outputs: Total A, Total B, Total C, Overall total 
'''

class_A = 20
class_B = 15
class_C = 10

def main():
  total_A = tickets_A()
  total_B = tickets_B()
  total_C = tickets_C()
  print(f'The total price of all tickets is ${total_A + total_B + total_C}')

def tickets_A(): 
  seats = int(input('How many class A tickets were sold? '))
  total_A = seats * class_A
  print(f'Total price of class A tickets were ${total_A}')
  return total_A

def tickets_B(): 
  seats = int(input('How many class B tickets were sold? '))
  total_B = seats * class_B
  print(f'Total price of class B tickets were ${total_B}')
  return total_B

def tickets_C(): 
  seats = int(input('How many class C tickets were sold? '))
  total_C = seats * class_C
  print(f'Total price of class C tickets were ${total_C}')
  return total_C

main()