'''
Chapter 5 Exercise 5
Jake Schrecengost

A county collects property taxes on the assessment value of property, which is 60 percent of the property’s actual value. Property tax is then 72¢ for each $100 of the assessment value. This program asks for the actual value of a piece of property and displays the assessment value and property tax.

Inputs: property value
Constants: n/a 
Outputs: assessment value, property tax 
'''

def main():
  property_value = float(input('Provide property value: $'))
  assessment_value = assessment_calculation(property_value)
  property_tax = tax_calculation(property_value)
  print(f'Property\'s estimated assessment value is: ${assessment_value:.2f}')
  print(f'Property\'s estimated tax is: ${property_tax:.2f}')

def assessment_calculation(value): 
  assessment_value = value * 0.6
  return assessment_value

def tax_calculation(value): 
  property_tax = ((value * 0.6) / 100) * 0.72
  return property_tax

main()
