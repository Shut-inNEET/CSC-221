'''
Chapter 7 Exercise 7
Jake Schrecengost

This application grades the written portion of
the driver’s license exam. The exam has 20 multiple-choice questions. This program stores the correct answers in a list. The program will read the student’s answers for each of the 20 questions from a text file and store the answers in another list. After the student’s answers have been read from the file, the program will display a message indicating whether the student passed or failed the exam. (A student must correctly answer 15 of the 20 questions to pass the exam.) It will then display the total number of correctly answered questions, the total number of incorrectly answered questions, and a list showing the question numbers of the incorrectly answered questions.

Inputs: correct answers text file, student answers text file
Constants: N/A
Outputs: pass or fail, total correct questions, total incorrect questions, list of incorrect question numbers
'''

def main():
  answer_key = open_cheatsheet()
  student_answers = open_studentsheet()
  correct, incorrect = compare_lists(answer_key, student_answers)
  score = test_score(correct)
  incorrect_list = show_incorrect(answer_key, student_answers)
  print(score)
  print(f'Correct number of questions: {correct}')
  print(f'Incorrect number of questions: {incorrect}')
  print(f'Incorrect questions are: {incorrect_list}')

def open_cheatsheet():
  infile = open('cheatsheet.txt', 'r')
  answer_key = infile.readlines()
  infile.close()
  for index in range(len(answer_key)):
    answer_key[index] = answer_key[index].rstrip('\n')
  return answer_key

def open_studentsheet():
  infile = open('studentsheet.txt', 'r')
  student_answers = infile.readlines()
  infile.close()
  for index in range(len(student_answers)):
    student_answers[index] = student_answers[index].rstrip('\n')
  return student_answers

def compare_lists(answer_key, student_answers):
  correct = 0
  for index in range(20):
    if answer_key[index] == student_answers[index]:
      correct += 1
  incorrect = 20 - correct
  return correct, incorrect

def test_score(correct):
  if correct >= 15:
    score = str('You passed')
  else:
    score = str('You failed')
  return score

def show_incorrect(answer_key, student_answers):
  incorrect_list = []
  for index in range(20):
    if answer_key[index] != student_answers[index]:
      wrong_question = index + 1
      incorrect_list.append(wrong_question)
  return incorrect_list

main()