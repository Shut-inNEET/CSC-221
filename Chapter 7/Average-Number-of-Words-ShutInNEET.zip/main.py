'''
Chapter 8 Exercise 6
Jake Schrecengost

text.txt is a file that contains text that is stored as one sentence per line. This program reads the file’s contents and calculates the average number of words per sentence. The Algorithm will:
- Read all the lines in the file into a list
- Initialize an accumulator variable for total count of words in the line
- For each line
  - Split the line into words
  - Determine the number of words in the list
  - Add that count to the total count for words
The program will then divide the total word count by the number of lines in the file to get the average number of words per sentence.


Inputs: text.txt
Constants: N/A
Outputs: average number of words per sentence.
'''

def main():
  lines_list = open_file()
  line_0, line_1, line_2, line_3, line_4, line_5, line_6, line_7, line_8, line_9 = split_lines(lines_list)
  line0_words, line1_words, line2_words, line3_words, line4_words, line5_words, line6_words, line7_words, line8_words, line9_words = split_words(line_0, line_1, line_2, line_3, line_4, line_5, line_6, line_7, line_8, line_9)
  total = count_words(line0_words, line1_words, line2_words, line3_words, line4_words, line5_words, line6_words, line7_words, line8_words, line9_words)
  average = total / len(lines_list)
  print(f'Average number of words per sentence: {average}')

def open_file():
  infile = open('text.txt', 'r')
  lines_list = infile.readlines()
  infile.close()
  for index in range(len(lines_list)):
    lines_list[index] = lines_list[index].rstrip('\n')
  return lines_list

def split_lines(lines_list):
  line_0 = lines_list[0]
  line_1 = lines_list[1]
  line_2 = lines_list[2]
  line_3 = lines_list[3]
  line_4 = lines_list[4]
  line_5 = lines_list[5]
  line_6 = lines_list[6]
  line_7 = lines_list[7]
  line_8 = lines_list[8]
  line_9 = lines_list[9]
  return line_0, line_1, line_2, line_3, line_4, line_5, line_6, line_7, line_8, line_9
  
def split_words(line_0, line_1, line_2, line_3, line_4, line_5, line_6, line_7, line_8, line_9):
  line0_words = line_0.split()
  line1_words = line_1.split()
  line2_words = line_2.split()
  line3_words = line_3.split()
  line4_words = line_4.split()
  line5_words = line_5.split()
  line6_words = line_6.split()
  line7_words = line_7.split()
  line8_words = line_8.split()
  line9_words = line_9.split()
  return line0_words, line1_words, line2_words, line3_words, line4_words, line5_words, line6_words, line7_words, line8_words, line9_words

def count_words(line0_words, line1_words, line2_words, line3_words, line4_words, line5_words, line6_words, line7_words, line8_words, line9_words):
  word_count0 = len(line0_words)
  word_count1 = len(line1_words)
  word_count2 = len(line2_words)
  word_count3 = len(line3_words)
  word_count4 = len(line4_words)
  word_count5 = len(line5_words)
  word_count6 = len(line6_words)
  word_count7 = len(line7_words)
  word_count8 = len(line8_words)
  word_count9 = len(line9_words)
  total = word_count0 + word_count1 + word_count2 + word_count3 + word_count4 + word_count5 + word_count6 + word_count7 + word_count8 + word_count9 
  return total

main()