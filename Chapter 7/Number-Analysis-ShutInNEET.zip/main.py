'''
Chapter 7 Exercise 4
Jake Schrecengost

This program asks the user to enter a series of 20 numbers. The program should store the numbers in a list then display the following data:
- The lowest number in the list
- The highest number in the list
- The total of the numbers in the list
- The average of the numbers in the list

Inputs: 20 numbers
Constants: N/A
Outputs: lowest number, highest number, total, average
'''

def main():
  user_list = get_input()
  max = myMax(user_list)
  min = myMin(user_list)
  sum = total(user_list)
  average = calc_avg(sum, user_list)
  print(f'Your max: {max}')
  print(f'Your min: {min}')
  print(f'Your total: {sum}')
  print(f'Your average: {average}')

def get_input():
  try:
    user_list = []
    remainder = 20
    for num in range(20):
      number = float(input(f'Enter a series of numbers ({remainder} left): '))
      remainder -= 1
      user_list.append(number)
      print()
    return user_list
  except ValueError:
    print('Please input a valid number')
    exit()

def myMax(user_list):
  max = user_list[0]
  for num in user_list:
    if num > max:
      max = num
  return max

def myMin(user_list):
  min = user_list[0]
  for num in user_list:
    if num < min:
      min = num
  return min

def total(user_list):
  sum = 0
  for num in range(len(user_list)):
    sum = sum + user_list[num]
  return sum

def calc_avg(sum, user_list):
  average = sum / len(user_list)
  return average

main()