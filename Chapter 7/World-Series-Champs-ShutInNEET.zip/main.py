'''
Chapter 7 Exercise 10
Jake Schrecengost

WorldSeriesWinners.txt is a file contains a chronological list of the World Series winning teams from 1903 through 2009. (The first line in the file is the name of the team that won in 1903, and the last line is the name of the team that won in 2009. Note the World Series was not played in 1904 or 1994.) This program lets the user enter the name of a team, then displays the number of times that team has won the World Series in the time period from 1903 through 2009.

Inputs: WorldSeriesWinners.txt, name of team
Constants: N/A
Outputs: number of times the team has won
'''

def main():
  world_series = open_file()
  input_team = input('Enter the name of a team: ')
  wins = find_team(world_series, input_team)
  print_wins(wins)

def open_file():
  infile = open('WorldSeriesWinners.txt', 'r')
  world_series = infile.readlines()
  infile.close()
  for index in range(len(world_series)):
    world_series[index] = world_series[index].rstrip('\n')
  return world_series

def find_team(world_series, input_team):
  wins = 0
  for index in range(len(world_series)):
    if input_team == world_series[index]:
      wins += 1
  return wins

def print_wins(wins):
  if wins > 1:
    print(f'This team has won World Series {wins} times.')
  elif wins == 1:
    print(f'This team has won World Series {wins} time.')
  else:
    print('This team has not won any World Series in the time period from 1903 through 2009.')

main()